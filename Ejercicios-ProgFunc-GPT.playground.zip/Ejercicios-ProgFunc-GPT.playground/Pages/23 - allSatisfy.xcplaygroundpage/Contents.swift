//: [Previous](@previous)

import Foundation

let productos: [String:String] = [
	"iPhone" : "Electrónica",
	"Sofá" : "Muebles",
	"Balón" : "Deportes",
	"Monitor" : "Electrónica"
]

let mismaCategoria = productos.allSatisfy { $0.value == "Electrónica" }

//: [Next](@next)
