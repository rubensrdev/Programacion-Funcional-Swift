//: [Previous](@previous)

import Foundation

struct Producto {
	let nombre:	String
	let categoria: String
	let stock:	Bool
}

let productos: [Producto] = [
	Producto(nombre: "Laptop", categoria: "Electrónica", stock: true),
	Producto(nombre: "Teléfono", categoria: "Electrónica", stock: false),
	Producto(nombre: "Mesa de comedor", categoria: "Muebles", stock: true),
	Producto(nombre: "Silla", categoria: "Muebles", stock: true),
	Producto(nombre: "Camiseta", categoria: "Ropa", stock: false),
	Producto(nombre: "Pantalones", categoria: "Ropa", stock: true),
	Producto(nombre: "Cafetera", categoria: "Electrodomésticos", stock: false),
	Producto(nombre: "Tostadora", categoria: "Electrodomésticos", stock: true),
	Producto(nombre: "Zapatillas", categoria: "Calzado", stock: true),
	Producto(nombre: "Libro de cocina", categoria: "Libros", stock: false)
]

let productosEnStock = productos.filter { $0.stock }.reduce(0) { count, _ in count + 1 }


//: [Next](@next)
