//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

let calendar = Calendar.current

let fecha1 = calendar.date(from: DateComponents(year: 2024, month: 1, day: 15))!
let fecha2 = calendar.date(from: DateComponents(year: 2023, month: 5, day: 22))!
let fecha3 = calendar.date(from: DateComponents(year: 2024, month: 3, day: 10))!
let fecha4 = calendar.date(from: DateComponents(year: 2022, month: 11, day: 30))!
let fecha5 = calendar.date(from: DateComponents(year: 2023, month: 12, day: 5))!

let fechas: [Date] = [fecha1, fecha2, fecha3, fecha4, fecha5]

let fechasOrdenadas = fechas
						.sorted { $0 > $1 }
						.prefix(3)
						.forEach { print($0.formatted(date: .abbreviated, time: .omitted)) }


//: [Next](@next)
