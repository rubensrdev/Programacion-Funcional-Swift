//: [Previous](@previous)

import Foundation

enum TipoPokemon {
	case electrico
	case planta
	case fuego
	case agua
	case normal
	case roca
	case fantasma
	case psiquico
	case lucha
	case bicho
	case dragon
}

struct Pokemon {
	let nombre: String
	let tipo: TipoPokemon
}

let pokemons: [Pokemon] = [
	Pokemon(nombre: "Pikachu", tipo: .electrico),
	Pokemon(nombre: "Bulbasaur", tipo: .planta),
	Pokemon(nombre: "Charmander", tipo: .fuego),
	Pokemon(nombre: "Squirtle", tipo: .agua),
	Pokemon(nombre: "Jigglypuff", tipo: .normal),
	Pokemon(nombre: "Meowth", tipo: .normal),
	Pokemon(nombre: "Psyduck", tipo: .agua),
	Pokemon(nombre: "Geodude", tipo: .roca),
	Pokemon(nombre: "Onix", tipo: .roca),
	Pokemon(nombre: "Gastly", tipo: .fantasma),
	Pokemon(nombre: "Abra", tipo: .psiquico),
	Pokemon(nombre: "Machop", tipo: .lucha),
	Pokemon(nombre: "Bellsprout", tipo: .planta),
	Pokemon(nombre: "Vulpix", tipo: .fuego),
	Pokemon(nombre: "Eevee", tipo: .normal),
	Pokemon(nombre: "Magikarp", tipo: .agua),
	Pokemon(nombre: "Scyther", tipo: .bicho),
	Pokemon(nombre: "Zapdos", tipo: .electrico),
	Pokemon(nombre: "Dragonite", tipo: .dragon)
]


pokemons.prefix(5).forEach {
	print($0.nombre)
}

//: [Next](@next)
