//: [Previous](@previous)

import Foundation

let palabras: [String] = ["hola", "adios", "siri", "IA"]
let menosDeDiezLetras = palabras.allSatisfy { $0.count < 10 }

//: [Next](@next)
