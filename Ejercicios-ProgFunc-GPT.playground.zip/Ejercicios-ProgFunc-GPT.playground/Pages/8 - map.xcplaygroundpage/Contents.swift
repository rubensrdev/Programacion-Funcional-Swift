//: [Previous](@previous)

import Foundation

struct Libro {
	let autor: String
	let titulo: String
	let editorial: String
}

let libros: [Libro] = [
	Libro(autor: "Brandon Sandersos", titulo: "El archivo de las tormentas", editorial: "Nova"),
	Libro(autor: "J.R.R. Tolkien", titulo: "El Señor de los Anillos: El retorno del Rey", editorial: "Booket")
]

let titulos = libros.map { $0.titulo }
titulos

//: [Next](@next)
