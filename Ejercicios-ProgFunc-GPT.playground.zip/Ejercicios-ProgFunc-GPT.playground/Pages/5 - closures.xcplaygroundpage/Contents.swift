//: [Previous](@previous)

import Foundation

let frase: (String, String) -> String = { "\($0) \($1)" }
frase("Idril quiere", "salir a pasear")

//: [Next](@next)
