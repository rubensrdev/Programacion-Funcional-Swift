//: [Previous](@previous)

import Foundation

let numerosNegativos: [Int] = [-1, -2, -3, -4, -5]
let numerosAbsolutos = numerosNegativos.map { abs($0) }

//: [Next](@next)
