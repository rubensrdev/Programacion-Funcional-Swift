//: [Previous](@previous)

import Foundation

let edades: [Int] = [18, 2, 30, 17, 25, 36, 44, 11, 15, 73, 24, 68]

let hastaElMayorDe60 = edades.drop(while: { $0 < 60 })
Array(hastaElMayorDe60)

//: [Next](@next)
