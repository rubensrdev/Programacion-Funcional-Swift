//: [Previous](@previous)

import Foundation

let laCompañiaDelAnillo: [String] = ["Frodo", "Sam", "Merry", "Pippin", "Gandalf", "Aragorn", "Legoles", "Gimli", "Boromir"]

let componentesMas5Letras = laCompañiaDelAnillo
	.filter { $0.count > 5 }
	.map { $0.uppercased() }
	.sorted()


//: [Next](@next)
