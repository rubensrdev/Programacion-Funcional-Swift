//: [Previous](@previous)

import Foundation

let inscripcionAnilloUnico = " Un anillo para gobernarlos a todos, Un anillo para encontrarlos, Un anillo para atraerlos a todos y atarlos en la oscuridad."

let contieneOscuridad = inscripcionAnilloUnico.contains("oscuridad")



//: [Next](@next)
