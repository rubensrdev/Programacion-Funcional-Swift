//: [Previous](@previous)

import Foundation

let numeros = (1...10).map { _ in Int.random(in: 1...10)}

let multiplicacionAPartirDe3 = numeros.dropFirst(3).map { $0 * 10 }

//: [Next](@next)
