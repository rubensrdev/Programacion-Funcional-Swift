//: [Previous](@previous)

import Foundation

let laCompañiaDelAnillo: [String] = ["Frodo", "Sam", "Merry", "Pippin", "Gandalf", "Aragorn", "Legoles", "Gimli", "Boromir"]
let compañiaOrdenInverso = laCompañiaDelAnillo
	.sorted { $0 < $1}
	.reversed()
Array(compañiaOrdenInverso)

//: [Next](@next)
