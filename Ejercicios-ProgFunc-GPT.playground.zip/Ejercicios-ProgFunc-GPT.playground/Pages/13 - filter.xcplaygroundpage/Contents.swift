//: [Previous](@previous)

import Foundation

struct Tarea {
	let nombre: String
	var pendiente: Bool = true
}

var tareas: [Tarea] = [
	.init(nombre: "Aprender Swift"),
	.init(nombre: "Aprender Algoritmia"),
	.init(nombre: "Aprender Programación Funcional"),
	.init(nombre: "Aprender SwiftUI")
]

tareas[0].pendiente = false
tareas[1].pendiente = false

let tareasPendientes = tareas.filter { $0.pendiente }


//: [Next](@next)
