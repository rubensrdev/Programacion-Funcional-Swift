//: [Previous](@previous)

import Foundation

let personajesDragonBall: [String] = ["Goku", "Vegeta", "Trunks", "Gohan", "Piccolo", "Cell"]
let borrarHastaGohan = personajesDragonBall.drop(while: { $0 != "Gohan" })
Array(borrarHastaGohan)


//: [Next](@next)
