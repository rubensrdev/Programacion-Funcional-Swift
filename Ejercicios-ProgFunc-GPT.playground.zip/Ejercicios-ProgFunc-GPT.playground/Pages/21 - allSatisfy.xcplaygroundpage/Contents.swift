//: [Previous](@previous)

import Foundation

let numeros = (1...10).map { _ in Int.random(in: -33...33) }
let sonPositivos = numeros.allSatisfy { $0 > 0 }

//: [Next](@next)
