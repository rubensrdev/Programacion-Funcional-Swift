//: [Previous](@previous)

import Foundation

let multiplicadosPorDos: ([Int]) -> [Int] = { array in
	array.map { $0 * 2 }
}

multiplicadosPorDos([1, 2, 3])
multiplicadosPorDos([9, 2, 18, 5])

//: [Next](@next)dsfdsf
