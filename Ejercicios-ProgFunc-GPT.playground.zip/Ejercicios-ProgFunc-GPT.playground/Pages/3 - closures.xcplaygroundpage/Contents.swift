//: [Previous](@previous)

import Foundation

let mayor: (Int, Int) -> Int = { $0 > $1 ? $0 : $1}
mayor(1, 2)
mayor(8, 4)
//: [Next](@next)
