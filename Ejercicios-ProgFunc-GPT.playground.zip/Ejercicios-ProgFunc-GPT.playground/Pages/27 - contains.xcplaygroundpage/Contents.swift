//: [Previous](@previous)

import Foundation

let numeros: [Int] = (1...100).map { _ in Int.random(in: 1...100) }
let contieneQuince = numeros.contains(15)

//: [Next](@next)
