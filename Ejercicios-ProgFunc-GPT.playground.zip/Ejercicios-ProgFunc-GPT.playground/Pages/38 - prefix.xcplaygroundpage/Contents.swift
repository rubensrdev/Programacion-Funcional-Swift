//: [Previous](@previous)

import Foundation

let saludo: String = "Hola amigo ¿que tal estás?"
let hola = saludo.prefix(4)
String(hola)

//: [Next](@next)
