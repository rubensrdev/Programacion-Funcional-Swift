//: [Previous](@previous)

import Foundation

let palabras: [String] = ["hola", "que", "tal", "como", "estas"]
let frase = palabras.reduce("") { partialResult, palabra in
	partialResult + " \(palabra)"
}

// joined es más optimizado
let frase2 = palabras.joined(separator: " ")


//: [Next](@next)
