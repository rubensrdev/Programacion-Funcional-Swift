//: [Previous](@previous)

import Foundation

let cuadrado = { (numero: Int) -> Int in
	numero * numero
}
cuadrado(5)
cuadrado(2)
cuadrado(7)

let cuadrado2: (Int) -> Int = { $0 * $0 }
cuadrado2(5)
cuadrado2(2)
cuadrado2(7)

//: [Next](@next)
