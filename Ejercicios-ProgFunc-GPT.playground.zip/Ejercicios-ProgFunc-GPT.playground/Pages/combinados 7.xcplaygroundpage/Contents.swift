//: [Previous](@previous)

import Foundation

let numeros = (1...10).map { _ in Int.random(in: 1...10)}
let stringOrdenados = numeros.sorted().map { String($0) }

//: [Next](@next)
