//: [Previous](@previous)

import Foundation

let numeros = (1...10).map { _ in Int.random(in: 1...25)}

let restultado = numeros
	.reduce(0) { partialValue, value in
		partialValue + value
	}
	
let resultadoMayor100 = restultado > 100

//: [Next](@next)
