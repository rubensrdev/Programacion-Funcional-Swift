//: [Previous](@previous)

import Foundation

let palabras: [String] = ["hola", "que", "tal", "como", "estas", "yo", "bien"]
let primeras3 = palabras.prefix(3)
Array(primeras3)

//: [Next](@next)
