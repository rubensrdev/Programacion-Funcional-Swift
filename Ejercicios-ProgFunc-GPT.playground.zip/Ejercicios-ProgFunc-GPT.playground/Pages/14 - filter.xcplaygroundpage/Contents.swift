//: [Previous](@previous)

import Foundation

let numeros = (1...10).map { _ in Int.random(in: 1...100) }
let limite = Int.random(in: 1...50)
let numerosSobreElLimite = numeros.filter { $0 > limite } 

//: [Next](@next)
