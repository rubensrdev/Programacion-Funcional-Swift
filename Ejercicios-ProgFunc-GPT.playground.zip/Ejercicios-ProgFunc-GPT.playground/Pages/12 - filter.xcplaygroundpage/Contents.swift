//: [Previous](@previous)

import Foundation

let personajesElSeñorDeLosAnillos = ["Gandalf", "Legolas", "Aragorn", "Boromir", "Gimli", "Sauron"]
let personajesMasDeSeisLetras = personajesElSeñorDeLosAnillos.filter { $0.count > 6}


//: [Next](@next)
