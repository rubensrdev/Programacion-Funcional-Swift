//: [Previous](@previous)

import Foundation

let numeros = [2, 43, 87, 5, 17, 25, 93, 125]
let numerosHasta17 = numeros.prefix(while: {$0 != 17})
Array(numerosHasta17)

//: [Next](@next)
