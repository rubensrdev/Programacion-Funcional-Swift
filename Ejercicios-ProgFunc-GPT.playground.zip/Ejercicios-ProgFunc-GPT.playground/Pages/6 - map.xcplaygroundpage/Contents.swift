//: [Previous](@previous)

import Foundation

let palabras: [String] = ["hola", "que", "tal", "como", "estas"]
let longitudes = palabras.map { $0.count }

//: [Next](@next)
