//: [Previous](@previous)

import Foundation

let alturasPersonas: [String: Double] = [
	"Rubén": 1.75,
	"María": 1.53,
	"Juan": 1.83,
	"Luis": 1.68,
	"Marisa": 1.61
]

let alturasHastaPrimerLimite = alturasPersonas.drop(while: { $0.value <= 1.80 })
Array(alturasHastaPrimerLimite)

//: [Next](@next)
