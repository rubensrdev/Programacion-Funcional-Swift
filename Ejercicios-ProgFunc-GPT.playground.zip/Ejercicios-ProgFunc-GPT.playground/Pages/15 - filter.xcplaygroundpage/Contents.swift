//: [Previous](@previous)

import Foundation

let peronajesDragonBall: [String] = ["Goku", "Vegeta", "Trunks", "Gohan", "Piccolo", "Cell"]
let personajesConG = peronajesDragonBall.filter { $0.lowercased().contains("g")}

//: [Next](@next)
