//: [Previous](@previous)

import Foundation

let personajesStarWars: [String] = ["Leia Organa", "Han Solo", "Chewbacca", "R2-D2", "C-3PO", "Luke Skywalker"]
let personajesMasDeOchoJuntos = personajesStarWars
	.filter { $0.count > 8}
	.reduce("") { partialName, name in
		partialName + ", \(name)"
	}

struct PersonajeDragonBall {
	let nombe: String
	let raza: [String]
}

let goku: PersonajeDragonBall = .init(nombe: "Goku", raza: ["saiyan"])
let gohan: PersonajeDragonBall = .init(nombe: "Gohan", raza: ["saiyan", "terrícola"])
let vegeta: PersonajeDragonBall = .init(nombe: "Vegeta", raza: ["saiyan"])
let trunks: PersonajeDragonBall = .init(nombe: "Trunks", raza: ["saiyan", "terrícola"])
let piccolo: PersonajeDragonBall = .init(nombe: "Piccolo", raza: ["namekiano"])
let krillin: PersonajeDragonBall = .init(nombe: "Krillin", raza: ["terrícola"])

let personajesDragonBall: [PersonajeDragonBall] = [goku, gohan, vegeta, trunks, piccolo, krillin]

let numDePersonajesTerricolas = personajesDragonBall
	.filter { $0.raza.contains("terrícola") && $0.raza.count == 1}
	.reduce(0) { count, personaje in count + 1 }

//: [Next](@next)
