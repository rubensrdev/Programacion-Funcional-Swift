//: [Previous](@previous)

import Foundation

let numeros: [Int] = [1, 2, 3, 4, 5]
let numerosPares = numeros.filter { $0 % 2 == 0 }

//: [Next](@next)
