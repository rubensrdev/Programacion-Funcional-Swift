//: [Previous](@previous)

import Foundation

let calendar = Calendar.current
let fecha1 = Date()
let fecha2 = calendar.date(from: DateComponents(year: 2024, month: 10, day: 28))!
let fecha3 = calendar.date(from: DateComponents(year: 1995, month: 3, day: 29))!

let fechas: [Date] = [fecha1, fecha2, fecha3]
let tieneCumpleaños = fechas.contains { $0 == fecha3}


//: [Next](@next)
