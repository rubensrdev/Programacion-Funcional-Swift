//: [Previous](@previous)

import Foundation

let laCompañiaDelAnillo: [String] = ["Frodo", "Sam", "Merry", "Pippin", "Gandalf", "Aragorn", "Legoles", "Gimli", "Boromir"]

let estaGandalf = laCompañiaDelAnillo.contains("Gandalf")
					&& laCompañiaDelAnillo.allSatisfy { $0.count > 3 }


//: [Next](@next)
