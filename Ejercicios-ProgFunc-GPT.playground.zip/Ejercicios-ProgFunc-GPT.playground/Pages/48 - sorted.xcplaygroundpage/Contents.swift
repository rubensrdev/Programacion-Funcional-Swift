//: [Previous](@previous)

import Foundation

struct Persona {
	let nombre: String
	let edad: Int
}

let personas = [
	Persona(nombre: "Rubén", edad: 29),
	Persona(nombre: "MAría", edad: 36),
	Persona(nombre: "Delia", edad: 35)
]

let personasOrdenadasPorEdadDeMayorAMenor = personas.sorted { $0.edad > $1.edad }
Array(personasOrdenadasPorEdadDeMayorAMenor)



//: [Next](@next)
