//: [Previous](@previous)

import Foundation

let multiplo: Int = 3
let numerosMultiplosTres: [Int] = [6, 9, 12, 15, 18, 21, 24, 27]
let sonMultiplos = numerosMultiplosTres.allSatisfy { $0 % multiplo == 0 }

//: [Next](@next)
