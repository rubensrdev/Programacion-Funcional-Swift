//: [Previous](@previous)

import Foundation

let numeros: [Int] = [1, 2, 18, 5, 11]
let suma = numeros.reduce(0) { partialResult, num in
	partialResult + num
}

let suma2 = numeros.reduce(0, +)

//: [Next](@next)
