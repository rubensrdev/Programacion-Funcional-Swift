//: [Previous](@previous)

import Foundation

let calendario = Calendar.current

let fechas = [
	calendario.date(from: DateComponents(year: 2024, month: 3, day: 29))!,
	calendario.date(from: DateComponents(year: 2022, month: 8, day: 14))!,
	calendario.date(from: DateComponents(year: 2023, month: 3, day: 10))!
]

let fechasOrdenCronologico = fechas.sorted { $0 < $1 }
fechasOrdenCronologico.forEach {
	print($0)
}

//: [Next](@next)
