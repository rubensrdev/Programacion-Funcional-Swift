//: [Previous](@previous)

import Foundation

let numeros: [Int] = (1...100).map { _ in Int.random(in: 1...66) }
let ordenadosAsc = numeros.sorted()

//: [Next](@next)
