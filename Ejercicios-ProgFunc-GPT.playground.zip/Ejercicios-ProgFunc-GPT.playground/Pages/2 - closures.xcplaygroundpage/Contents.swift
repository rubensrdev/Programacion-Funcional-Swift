//: [Previous](@previous)

import Foundation

let longitud: (String) -> Int = { $0.count }
print(longitud("Goku vs Frieza"))

let longitud2 = { (palabra: String) -> Int in
	palabra.count
}
longitud("Goku vs Frieza")

//: [Next](@next)
