//: [Previous](@previous)

import Foundation

let numerosAleatorios: [Int] = (1...10).map { _ in Int.random(in: 1...50)}
let valorMaximo = numerosAleatorios.reduce(0) {max, num in max > num ? max : num }


//: [Next](@next)
