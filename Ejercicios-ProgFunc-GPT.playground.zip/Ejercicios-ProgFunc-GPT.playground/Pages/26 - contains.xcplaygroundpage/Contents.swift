//: [Previous](@previous)

import Foundation

let nombres: [String] = ["Juan", "Pedro", "Luis", "Maria", "Ana"]
let estaMaria = nombres.contains("Maria")

//: [Next](@next)
