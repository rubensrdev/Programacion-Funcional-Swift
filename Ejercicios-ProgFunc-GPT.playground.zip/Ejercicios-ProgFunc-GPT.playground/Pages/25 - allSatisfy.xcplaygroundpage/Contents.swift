//: [Previous](@previous)

import Foundation

struct PersonajeDragonBall {
	let nombe: String
	let raza: [String]
}

let goku: PersonajeDragonBall = .init(nombe: "Goku", raza: ["saiyan"])
let gohan: PersonajeDragonBall = .init(nombe: "Gohan", raza: ["saiyan", "terrícola"])
let vegeta: PersonajeDragonBall = .init(nombe: "Vegeta", raza: ["saiyan"])
let trunks: PersonajeDragonBall = .init(nombe: "Trunks", raza: ["saiyan", "terrícola"])
let piccolo: PersonajeDragonBall = .init(nombe: "Piccolo", raza: ["namekiano"])
let krillin: PersonajeDragonBall = .init(nombe: "Krillin", raza: ["terrícola"])

let personajesDragonBall: [PersonajeDragonBall] = [goku, gohan, vegeta, trunks, piccolo, krillin]

let sonSaiyan = personajesDragonBall.allSatisfy { $0.raza.contains("saiyan")}

//: [Next](@next)
