//: [Previous](@previous)

import Foundation

struct pokemon {
	let nombre: String
	let tipo: String
}

let pikachu = pokemon(nombre: "Pikachu", tipo: "Electrico")
let bulbasaur = pokemon(nombre: "Bulbasaur", tipo: "Planta")
let charmander = pokemon(nombre: "Charmander", tipo: "Fuego")
let squirtle = pokemon(nombre: "Squirtle", tipo: "Agua")

let pokemonsIniciales: [pokemon] = [pikachu, bulbasaur, charmander, squirtle]

let pokemonHastaTipoPlanta = pokemonsIniciales.filter { $0.tipo != "Planta"}.prefix(1)
Array(pokemonHastaTipoPlanta)

//: [Next](@next)
