//: [Previous](@previous)

import Foundation

let calendario = Calendar.current

let fecha1 = calendario.date(from: DateComponents(year: 2023, month: 10, day: 27))
let fecha2 = calendario.date(from: DateComponents(year: 2024, month: 1, day: 15))
let fecha3 = calendario.date(from: DateComponents(year: 2025, month: 5, day: 30))

let fechas: [Date?] = [
	fecha1,
	fecha2,
	fecha3
]

let fechasFormateadas = fechas.map { $0?.formatted(date: .complete, time: .omitted) }
fechasFormateadas.forEach {
	if let fecha = $0 {
		print(fecha)
	}
}


//: [Next](@next)
