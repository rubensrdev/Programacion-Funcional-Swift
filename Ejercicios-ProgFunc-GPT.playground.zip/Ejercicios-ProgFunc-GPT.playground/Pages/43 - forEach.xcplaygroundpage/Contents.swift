//: [Previous](@previous)

import Foundation

var numeros: [Int] = [1, 2, 3, 4, 5]
var pares: [Int] = []
numeros.forEach {
	if $0.isMultiple(of: 2) {
		pares.append($0)
	}
}
pares

numeros = [1, 2, 3, 4, 5,6,7,8,9,10]
pares = numeros.filter { $0.isMultiple(of: 2) }
pares
//: [Next](@next)
