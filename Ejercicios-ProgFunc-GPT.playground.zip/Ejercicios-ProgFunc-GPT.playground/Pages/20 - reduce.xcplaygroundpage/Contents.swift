//: [Previous](@previous)

import Foundation

let numeros: [Double] = (1...5).map { _ in Double.random(in: 1...1000) }
let promedio = numeros.isEmpty ? 0 : (numeros.reduce(0.0, +) / Double(numeros.count)).rounded() / 10
//: [Next](@next)
