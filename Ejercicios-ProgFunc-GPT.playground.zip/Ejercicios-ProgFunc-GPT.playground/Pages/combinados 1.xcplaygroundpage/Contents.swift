//: [Previous](@previous)

import Foundation

let numeros = (1...10).map { _ in Int.random(in: 1...100)}

let cuadradosPares = numeros
						.map { $0 * $0 }
						.filter { $0.isMultiple(of: 2) }


//: [Next](@next)
