//: [Previous](@previous)

import Foundation

let numeros: [Int] = [1, 2, 3, 4, 5]

numeros.forEach {
	print($0 + 1)
}

//: [Next](@next)
